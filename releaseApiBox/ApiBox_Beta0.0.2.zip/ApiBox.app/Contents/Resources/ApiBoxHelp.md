# ApiBox
##Write Engaging Api . in One Elegant Place.

![ApiBox example](http://www.egs-studio.com/ApiBox/static/images/screens/apiBox2.png)

Hello there! I’m **ApiBox**, the **ApiBlueprint** Markdown editor for OS X.

---

# What is ApiBox.

1. ApiBox use a classical API language.[ApiBlueprint](www.apiblueprint.org) and easy to mark Api Document.
2. ApiBox is also a simple Markdown editor for OS X.

# Any question？

1. find us on <http://www.egs-studio.com/ApiBox>


Happy Exploring !

