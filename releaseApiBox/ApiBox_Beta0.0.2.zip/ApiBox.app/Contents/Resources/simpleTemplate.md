FORMAT: 1A
HOST: https://api.mywebsite.com


# 新Api文档---精简版
简单模板.支持Mardown语法的描述。（全文在描述的地方都可以使用markdown标记）`Markdown`  **formatted** *description*.

## Api文档副标题
Also Markdown *formatted*. 副标题描述。
```
注释:大段大段文字的注释，以及一些特别说明可以放在这个安全区域。避免纠结在解析ApiBlueprint格式错误。
```
>  说明1...
>  说明2...

# Group Notes 分组A
*Group* **description** (also `with` *Markdown*) 

## /notes/token
+ Parameters

    + name (optional, string, `alice`) ... Search for a user by name


### GET
```
注释:解析ApiBlueprint格式发生错误时，可以事后查阅 ‘Help-->ApiBlueprint Document' 的API Blueprint 语法文档。或者特别格式在放在这个  codeBlock区域中。
```
Request a TT token.

+ Response 200 (application/json)

            {
                "title": "My new note",
                "body": "..."
            }

## /notes/token2
+ Parameters

    + name (optional, string, `alice`) ... Search for a user by name
    + joinedBefore (optional, string, `2011-01-01`) ... Search by join date

### GET
Request a TT token2.

+ Response 200 (application/json)

            {
                "title": "My token2",
                "body": "..."
            }



# Group Pen 分组B
*Group* **description** (also `with` *Markdown*) 

## /Pen/token
+ Parameters

    + name (optional, string, `alice`) ... Search for a user by name


### GET
Request a TT token.

+ Response 200 (application/json)

            {
                "title": "My new note",
                "body": "..."
            }

## /Pen/token2
+ Parameters

    + name (optional, string, `alice`) ... Search for a user by name
    + joinedBefore (optional, string, `2011-01-01`) ... Search by join date

### GET
Request a TT token2.

+ Response 200 (application/json)

            {
                "title": "My token2",
                "body": "..."
            }

