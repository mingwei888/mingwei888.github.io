FORMAT: 1A
HOST: https://api.mywebsite.com


# 新Api文档
简单模板.支持Mardown语法的描述。（全文在描述的地方都可以使用markdown标记）`Markdown`  **formatted** *description*.

## Api文档副标题
Also Markdown *formatted*. 副标题描述。
```
code block...
```
>  说明1...
>  说明2...

# Group Notes 分组一
*Group* **description** (also `with` *Markdown*) 

## Note List [/notes]
Note **list** **description**

+ Parameters

    + name (optional, string, `alice`) ... Search for a user by name
    + joinedBefore (optional, string, `2011-01-01`) ... Search by join date
    + joinedAfter (optional, string, `2011-01-01`) ... Search by join date
    + sort = `name` (optional, string, `joined`) ... Which field to sort by

        + Values
            + `name`
            + `joined`
            + `-joined`
            + `age`

    + limit = `10` (optional, integer, `25`) ... The maximum number of users to return, up to `50`



### Get Notes [GET]
Get a **list** of notes.

+ Response 200 (application/json)

            {
                "title": "My new note",
                "body": "..."
            }

### Create New Note [POST]
Create a new **note**

+ Request



+ Response 201

+ Response 400



## Note [/notes/{id}]
Note description

+ Parameters

    + name (optional, string, `alice`) ... Search for a user by name

+ id (required, string, `68a5sdf67`) ... The note ID

+ Model



### Get Note [GET]
Get a single note.

+ Response 200

[Note][]

+ Response 404



### Update a Note [PUT]
Update a single note

+ Parameters

    + name (optional, string, `alice`) ... Search for a user by name

### Delete a Note [DELETE]
Delete a single note


# Group Users分组二
Group **description**

## User List [/users{?name,joinedBefore,joinedAfter,sort,limit}]
A list of users

+ Parameters

    + name (optional, string, `alice`) ... Search for a user by name

 



### Get users [GET]
Get a list of users. Example:

```no-highlight
https://api.mywebsite.com/users?sort=joined&limit=5 
```

+ Response 200

[User List][]

# Group Tags and Tagging Long Title
Get or set **tags** on notes

## GET alltag [/tags]
Get a list of bars

### xxxx [GET]
+ Response 200

## Get one tag [/tags/{id}]
Get a single tag

### yyyyy [GET]

+ Response 200